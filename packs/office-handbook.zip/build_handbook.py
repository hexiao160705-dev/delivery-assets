from pathlib import Path
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "_build"))
from html_pdf import write_html, write_pdf, count_chinese
from content import CHAPTERS, REWRITE_PAIRS, PROMPT_CARDS, HANDBOOK_TITLE, HANDBOOK_SUBTITLE


ROOT = Path(__file__).resolve().parent


def chapter_blocks():
    blocks = [
        {"kind": "note", "text": "本手册为原创办公方法整理，含 AI 辅助起草。所有案例均为虚构情境，数字为示例。法律、教学、HR 内容只提供办公辅助方法，不替代专业判断。"},
        {"kind": "h2", "text": "目录"},
        {"kind": "ol", "items": [chapter["title"] for chapter in CHAPTERS]},
    ]
    for index, chapter in enumerate(CHAPTERS, start=1):
        blocks.append({"kind": "pagebreak"})
        blocks.append({"kind": "h2", "text": f"第{index}章 {chapter['title']}"})
        blocks.append({"kind": "h3", "text": "职业挑战"})
        blocks.append({"kind": "p", "text": chapter["challenge"]})
        blocks.append({"kind": "h3", "text": "AI解法"})
        blocks.append({"kind": "p", "text": chapter["solution"]})
        blocks.append({"kind": "h3", "text": "可复制步骤"})
        blocks.append({"kind": "ol", "items": chapter["steps"]})
        blocks.append({"kind": "h3", "text": "场景示例"})
        blocks.append({"kind": "p", "text": chapter["example"]})
        blocks.append({"kind": "h3", "text": "使用边界"})
        blocks.append({"kind": "note", "text": chapter["boundary"]})
    return blocks


def rewrite_blocks():
    blocks = [
        {"kind": "note", "text": "10 组前后对照均为自写示例。改写保留事实，删除空句，把抽象词换成动作、数字或例子。示例数字需替换为真实数据。"},
    ]
    for index, pair in enumerate(REWRITE_PAIRS, start=1):
        blocks.append({"kind": "h2", "text": f"{index:02d} {pair['scene']}"})
        blocks.append({"kind": "h3", "text": "改写前"})
        blocks.append({"kind": "p", "text": pair["before"]})
        blocks.append({"kind": "h3", "text": "改写后"})
        blocks.append({"kind": "p", "text": pair["after"]})
        blocks.append({"kind": "note", "text": pair["reason"]})
    return blocks


def prompt_blocks():
    blocks = [
        {"kind": "note", "text": "30 张提示词卡均为自写。每张包含场景、提示词、预期输出和常见坑。提示词可直接复制，但涉及敏感数据、专业判断和对外发布时，先按所在机构规则确认。"},
    ]
    for index, card in enumerate(PROMPT_CARDS, start=1):
        blocks.append({"kind": "h2", "text": f"卡{index:02d} {card['scene']}"})
        blocks.append({"kind": "h3", "text": "提示词"})
        blocks.append({"kind": "p", "text": card["prompt"]})
        blocks.append({"kind": "h3", "text": "预期输出"})
        blocks.append({"kind": "p", "text": card["output"]})
        blocks.append({"kind": "h3", "text": "常见坑"})
        blocks.append({"kind": "note", "text": card["pitfall"]})
    return blocks


def combined_blocks():
    blocks = [
        {"kind": "h2", "text": "第一部分 AI办公提效手册"},
        *chapter_blocks(),
        {"kind": "pagebreak"},
        {"kind": "h2", "text": "第二部分 去AI味改写指南"},
        *rewrite_blocks(),
        {"kind": "pagebreak"},
        {"kind": "h2", "text": "第三部分 办公提示词30卡"},
        *prompt_blocks(),
    ]
    return blocks


def main():
    parts = [
        ("AI办公提效手册", HANDBOOK_SUBTITLE, chapter_blocks()),
        ("去AI味改写指南", "10 组前后对照", rewrite_blocks()),
        ("办公提示词30卡", "场景、提示词、预期输出、常见坑", prompt_blocks()),
    ]
    stats = []
    for title, subtitle, blocks in parts:
        write_html(ROOT / f"{title}.html", title, blocks, subtitle)
        write_pdf(ROOT / f"{title}.pdf", title, blocks, subtitle)
        text = "\n".join(block.get("text", "") + "\n".join(block.get("items", [])) for block in blocks)
        stats.append({"title": title, "chinese_chars": count_chinese(text)})
    blocks = combined_blocks()
    write_html(ROOT / "handbook.html", "AI办公手册合集", blocks, "8 章手册、10 组改写对照、30 张提示词卡")
    write_pdf(ROOT / "handbook.pdf", "AI办公手册合集", blocks, "8 章手册、10 组改写对照、30 张提示词卡")
    manifest = {
        "generated_at": "2026-11-23",
        "chapters": len(CHAPTERS),
        "profession_chapters": ["律师", "教师", "HR"],
        "rewrite_pairs": len(REWRITE_PAIRS),
        "prompt_cards": len(PROMPT_CARDS),
        "parts": stats,
        "combined_chinese_chars": count_chinese("\n".join(block.get("text", "") + "\n".join(block.get("items", [])) for block in blocks)),
    }
    (ROOT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
